export {default} from "./2250afbe870c551f@41.js";
