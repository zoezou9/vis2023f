export {default} from "./72a88d36fe2e84e6@18.js";
